import random

def chooseRandWord():
    words = []
    with open("words.txt") as f:
        line = f.readline().strip()
        words.append(line)
        while line:
            line = f.readline().strip()
            words.append(line)

    randindex = random.randint(0, len(words)-1)
    return words[randindex]

print("welcome to my little project ")
secret_word = chooseRandWord()
print(secret_word)

dashes = list(secret_word)
dispList = []
for i in dashes:
    dispList.append("_")
print(dispList)
count = len(secret_word)
guesses = 0
letter = 0
usedList = []
while count != 0 and letter != "exit" :
    print(" ".join(dispList))
    letter = input("guess a letter: ")
    if letter.upper() in usedList:
        print("you already guessed that letter")
    else :
        for i in range(0,len(secret_word)):
            if letter.upper() == secret_word[i]:
                dispList[i] = letter.upper()
                count -=1
        guesses+=1
    usedList.append(letter.upper())
if letter == "exit":
    print("bye")
else:
    print(" ".join(dispList))
    print("you guessed that the word is " + secret_word + " after %s guesses" % guesses)
