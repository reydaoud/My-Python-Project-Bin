import time
import random

def diceRoll():
    randomNumber = random.randint(1,6)
    return randomNumber

def main():
    p1Win = 0
    p2Win = 0
    p1 = 0
    p2 = 0
    rounds = 1
    while rounds < 11:
        
        print("round " + str(rounds))
        p1 = diceRoll()
        p2 = diceRoll()
        print("player 1: " + str(p1))
        time.sleep(0.75)
        print("player 2: " + str(p2))
        time.sleep(0.555555555555555555555555555555)
        if p1 > p2:
            print("player 1 has won this round")
            p1Win += 1
        elif p2 > p1:
            print("player 2 has won this round")
            p2Win +=1
        else:
            print("This round is a tie!")
            p1Win += 1
            p2Win += 1
        rounds += 1
    print("this game has ended with the score: P1: "+ str(p1Win) + " P2: " + str(p2Win))

    time.sleep(0.5)

    if p1Win > p2Win:
        print("the person who won the game is Player 1")
    elif p2Win > p1Win:
        print("the person who won the game is Player 2")
    else:
        print("the game ended in a draw")
        
main()
