alphabet = "abcdefghijklmnopqrstuvwxyz"
alphabetupper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
newmsg = ''
msg = input("enter your message: ").lower()

key = int(input("enter your number from 1-26: "))

for character in msg:
    if character in alphabet:
        pos = alphabet.find(character)
        newpos = (pos + key) % 26
        newchar = alphabet[newpos]
        newmsg += newchar
    else:
        newmsg += character
print(newmsg)
