import random

choices = ['rock', 'paper', 'scissors']

round = 1
plrscore = 0
cptscore = 0

while round < 10:
    playerchoice = input("choose rock, paper, or scissors: ")
    if playerchoice not in choices:
        print("please choose rock, paper, or scissors")

        continue

    computerchoice = random.choice(choices)

    print("computer choice: ", computerchoice)


    if playerchoice == "rock":
        if computerchoice == "paper":
            print("Computer wins!")
            cptscore += 1
        if computerchoice == "scissors":
            print("You win!")
            plrscore += 1
        else:
            print("draw!")
            plrscore += 1
            cptscore += 1

    if playerchoice == "paper":
        if computerchoice == "scissors":
            print("Computer wins!")
            cptscore += 1
        if computerchoice == "rock":
            print("You win!")
            plrscore += 1
        else:
            print("draw!")
            plrscore += 1
            cptscore += 1

    if playerchoice == "scissors":
        if computerchoice == "rock":
            print("Computer wins!")
            cptscore += 1
        if computerchoice == "paper":
            print("You win!")
            plrscore += 1
        else:
            print("draw!")
            plrscore += 1
            cptscore += 1
    round += 1
print("the final score is: player: " + str(plrscore) + " : computer: "+ str(cptscore) )
if plrscore > cptscore:
    print("You win!")
elif plrscore < cptscore:
    print("You lose!")
else:
    print("Draw!")



