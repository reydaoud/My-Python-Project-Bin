import random

print("--- BANK HEIST SIMULATOR ---")
print("You are standing in front of the city bank You have a crowbar and stealth gear")

while True:
    choice1 = input("Do you want to enter through the front door or the vent ").lower()

    if choice1 == "front door":
        print("The guard sees you immediately")
        action = input("Do you run or bribe him ").lower()
        if action == "bribe":
            money = random.randint(1, 100)
            if money > 50:
                print("He took the cash and let you in Lucky you")
                path_success = True
            else:
                print("He finds your bribe insulting Youre arrested")
                path_success = False
        else:
            print("You arent fast enough Busted!")
            path_success = False

    elif choice1 == "vent":
        print("You crawl through the dusty vents and reach the vault room")
        path_success = True

    else:
        print("You tripped on the sidewalk and gave up")
        path_success = False

    if path_success:
        print("You are at the vault It needs a 1-digit master code")
        vault_guess = input("Enter a number (0-9): ")
        secret_code = str(random.randint(0, 9))

        if vault_guess == secret_code:
            print("CLANK The vault opens! Youre rich!")
        else:
            print("ALARM! The code was " + secret_code + " You leave empty-handed")

    retry = input("\nTry the heist again? (Y/N): ").upper()
    if retry != "Y":
        print("Criminal life isnt for everyone")
        break