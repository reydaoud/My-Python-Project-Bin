#---Libraries---#
import random


#---code---#

minimum = 1
maximum = 1000
middle = int(round((minimum + maximum) / 2))
print("my guess is " , middle)
count = 1
guess = input("is it too high? too low? or correct? \n")
while guess != "exit":
    if guess == "too high":
        maximum = middle - 1
        middle = int(round((minimum + maximum) / 2))
        print("my guess is ", middle)
        count += 1
        guess = input("is it too high? too low? or correct? \n")

    if guess == "too low":
        minimum = middle + 1
        middle = int(round((minimum + maximum) / 2))
        print("my guess is ", middle)
        count += 1
        guess = input("is it too high? too low? or correct? \n")
    elif guess == "correct":
        print("i got it loser heahahaahahahhahah and it only took me " + str(count) + " times to guess it")
        y_n = input("Wanna keep playing loser? type Y for yes or N for no: \n")
        if y_n == "Y":
            maximum = 1000
            minimum = 1
            middle = int(round((minimum + maximum) / 2))
            print("my guess is ", middle)
            count = 1
            guess = input("is it too high? too low? or correct? \n")
        elif y_n == "N":
            print("ur not fun anyway")
            break

