#Libraries#
#-----------#
import random
import time
#-----------#

file = open("responses.txt", "r")
magic_responses = file.readlines()
def magic8ball():
    question = input("ask the magic ball a yes or no question: \n")
    print("thinking...")
    time.sleep(random.randrange(2,5))
    print("the magic 8Ball responds with: ")
    print(random.choice(magic_responses))

while True:
    magic8ball()
    repeat = input("would u like to ask another question? (Y or N): \n")
    if not(repeat == "y" or repeat == "Y"):
        print("Come back when u feel like u want to.")
        break


