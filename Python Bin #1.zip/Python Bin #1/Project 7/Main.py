import turtle
import random
screen = turtle.Screen()
screen.setup(800, 600)
#turtles player stats#

player = turtle.Turtle()
player2 = turtle.Turtle()
player.color("red")
player.shape("turtle")
player2.color("blue")
player2.shape("turtle")
player.penup()
player2.penup()
player.goto( -200,100)
player2.goto( -200,-100)


player.goto(300 , 60)
player.pendown()
player.circle(40)
player.penup()
player.goto(-200,100)

player2.goto(300 , -140)
player2.pendown()
player2.circle(40)
player2.penup()
player2.goto(-200,-100)

dice = [1,2,3,4,5,6]

for i in range(20):
    if player.pos() >= (300, 100):
        print("player 1 wins!")
        break
    elif player2.pos() >= (300, -100):
        print("player 2 wins!")
        break
    else :
        p1turn = input("press enter to roll the dice \n")
        dice_nb = random.choice(dice)
        print("the number of the dice is " + str(dice_nb))
        print("the number of the steps will be " + str(20*dice_nb))
        player.forward(dice_nb*20)

        p2turn = input("press enter to roll the dice \n")
        dice_nb2 = random.choice(dice)
        print("the number of the dice is " + str(dice_nb2))
        print("the number of the steps will be " + str(20 * dice_nb2))
        player2.forward(dice_nb2 * 20)

screen.mainloop()
