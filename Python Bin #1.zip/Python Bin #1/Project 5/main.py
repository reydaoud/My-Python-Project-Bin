import urllib.request
import json
import turtle

#---astros info---#
url_astros = 'http://api.open-notify.org/astros.json'

req = urllib.request.urlopen(url_astros)
response = json.loads(req.read())
print("in the iss we have: ", response['number'])
ppl = response['people']
for i in ppl:
    print(i['name'],' in ', i['craft'])

#---iss location---#
url_iss  = 'http://api.open-notify.org/iss-now.json'
req2 = urllib.request.urlopen(url_iss)
response = json.loads(req2.read())
location = response['iss_position']
print("the iss is curently orbiting around:", location)

#---UI/UX---#

screen = turtle.Screen()
screen.setup(720 , 360)
screen.setworldcoordinates(-180, -90, 180, 90)
screen.bgpic('map.gif')

screen.register_shape('iss.gif')
iss = turtle.Turtle()
iss.shape('iss.gif')
iss.setheading(90)
lat = float(location['latitude'])
lon = float(location['longitude'])
iss.goto(lon, lat)

screen.exitonclick()
